<?php
// src/templates/footer.php
?>
    <hr>
    <footer class="text-center py-3">
        <p>&copy; <?php echo date('Y'); ?> Subplanet. All rights reserved.</p>
    </footer>
</body>
</html>
