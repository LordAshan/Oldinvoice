-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2024 at 03:29 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `subplanet_invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `purchase_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `payment_status` enum('Paid','Not Paid','Partial') NOT NULL DEFAULT 'Not Paid',
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(5,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `order_number`, `purchase_date`, `expire_date`, `client_name`, `customer_phone`, `payment_status`, `subtotal`, `discount`, `total`) VALUES
(1, 'SP202410040001', '2024-10-04', '2025-04-04', 'Mr jayantha', '0717748422', 'Paid', 32424.00, 0.00, 32424.00),
(3, 'SP202410050001', '2024-10-05', '2025-10-05', 'perera', '0717748422', 'Partial', 3500.00, 0.00, 3500.00),
(4, 'SP202410050002', '2024-10-05', '2025-01-05', 'ashan', '0717748422', 'Partial', 3500.00, 0.00, 3500.00),
(5, 'SP202410050003', '2024-10-05', '2025-10-05', 'perera', '0717748422', 'Partial', 3500.00, 0.00, 3500.00),
(6, 'SP202410050004', '2024-10-05', '2024-12-05', 'ashan', '0717748422', 'Paid', 10433.00, 15.00, 8868.05),
(7, 'SP202410050005', '2024-10-05', '2029-10-05', 'perera', '0717748422', 'Paid', 6933.00, 15.00, 5893.05),
(8, 'SP202410050006', '2024-10-05', '2024-12-05', 'ashan', '0717748422', 'Paid', 10433.00, 15.00, 8868.05),
(9, 'SP202410050007', '2024-10-05', '2024-12-05', 'ashan', '0717748422', 'Paid', 10433.00, 15.00, 8868.05),
(10, 'SP202410050008', '2024-10-05', '2025-01-05', 'perera', '0717748422', 'Not Paid', 6933.00, 15.00, 5893.05),
(11, 'SP202410050009', '2024-10-05', '2024-11-05', 'perera', '0717748422', 'Not Paid', 6933.00, 15.00, 5893.05),
(12, 'SP202410050010', '2024-10-05', '2026-10-05', 'ashan', '0717748422', 'Paid', 6933.00, 21.00, 5477.07),
(13, 'SP202410050011', '2024-10-05', '2026-10-05', 'ashan', '0717748422', 'Paid', 3500.00, 45.00, 1925.00),
(14, 'SP202410050012', '2024-10-05', '2024-11-05', 'ashan', '0717748422', 'Not Paid', 6933.00, 15.00, 5893.05),
(15, 'SP202410050013', '2024-10-05', '2024-12-05', 'perera', '0717748422', 'Paid', 6933.00, 10.00, 6239.70),
(16, 'SP202410050014', '2024-10-05', '2024-11-05', 'Mr jayantha', '0717748422', 'Partial', 6933.00, 10.00, 6239.70),
(17, 'SP202410050015', '2024-10-05', '2024-11-05', 'ashan', '0717748422', 'Not Paid', 6933.00, 15.00, 5893.05),
(18, 'SP202410050016', '2024-10-05', '2025-01-05', 'Yohan Perera', '0717748422', 'Paid', 3500.00, 15.00, 2975.00),
(19, 'SP202410050017', '2024-10-05', '2025-01-05', 'Yohan Perera', '0717748422', 'Paid', 3500.00, 15.00, 2975.00),
(20, 'SP202410050018', '2024-10-05', '2027-10-05', 'Mr jayantha', '0717748422', 'Paid', 3500.00, 10.00, 3150.00),
(21, 'SP202410050019', '2024-10-05', '2025-01-05', 'Mr jayantha', '0717748422', 'Partial', 3433.00, 0.00, 3433.00),
(22, 'SP202410050020', '2024-10-05', '2024-12-05', 'Mr jayantha', '0717748422', 'Not Paid', 6933.00, 20.00, 5546.40),
(23, 'SP202410050021', '2024-10-05', '2024-12-05', 'Mr jayantha', '0717748422', 'Not Paid', 6933.00, 20.00, 5546.40),
(24, 'SP202410050022', '2024-10-05', '2024-11-05', 'Mr jayantha', '0717748422', 'Paid', 950.00, 5.00, 902.50),
(25, 'SP202410050023', '2024-10-05', '2024-11-05', 'Mr jayantha', '0717748422', 'Paid', 950.00, 5.00, 902.50),
(26, 'SP202410050024', '2024-10-05', '2025-10-05', 'Mr jayantha', '0717748422', 'Not Paid', 6933.00, 2.00, 6794.34),
(27, 'SP202410050025', '2024-10-05', '2025-10-05', 'Mr jayantha', '0717748422', 'Not Paid', 6933.00, 2.00, 6794.34),
(28, 'SP202410050026', '2024-10-05', '2024-11-05', 'Mr jayantha', '0717748422', 'Partial', 6933.00, 10.00, 6239.70),
(29, 'SP202410050027', '2024-10-05', '2024-11-05', 'Mr jayantha', '0717748422', 'Partial', 6933.00, 10.00, 6239.70),
(30, 'SP202410050028', '2024-10-05', '2024-11-05', 'Mr jayantha', '0717748422', 'Partial', 6933.00, 10.00, 6239.70),
(31, 'SP202410050029', '2024-10-05', '2024-12-05', 'Yohan Perera', '0717748422', 'Partial', 950.00, 0.00, 950.00),
(32, 'SP202410050030', '2024-10-05', '2024-12-05', 'perera', '0717748422', 'Paid', 7883.00, 4.00, 7567.68),
(33, 'SP202410050031', '2024-10-05', '2025-04-05', 'perera', '0717748422', 'Not Paid', 6933.00, 0.00, 6933.00),
(34, 'SP202410050032', '2024-10-05', '2024-12-05', 'perera', '0717748422', 'Paid', 7883.00, 4.00, 7567.68),
(35, 'SP202410050033', '2024-10-05', '2025-04-05', 'Yohan Perera', '0717748422', 'Not Paid', 6283.00, 2.00, 6157.34),
(36, 'SP202410050034', '2024-10-05', '2025-04-05', 'Yohan Perera', '0717748422', 'Not Paid', 6283.00, 2.00, 6157.34),
(37, 'SP202410050035', '2024-10-05', '2025-10-05', 'ashan', '0717748422', 'Paid', 0.00, 0.00, 0.00),
(38, 'SP202410050036', '2024-10-05', '2025-10-05', 'ashan', '0717748422', 'Paid', 3433.00, 4.00, 3295.68),
(39, 'SP202410050037', '2024-10-05', '2024-12-05', 'perera', '0717748422', 'Not Paid', 950.00, 4.00, 912.00),
(40, 'SP202410050038', '2024-10-05', '2025-10-05', 'Mr jayantha', '0717748422', 'Not Paid', 7950.00, 5.00, 7552.50),
(41, 'SP202410050039', '2024-10-05', '2024-12-05', 'Yohan Perera', '0717748422', 'Paid', 4383.00, 3.00, 4251.51),
(42, 'SP202410050040', '2024-10-05', '2027-10-05', 'Yohan Perera', '0717748422', 'Partial', 3433.00, 10.00, 3089.70),
(43, 'SP202410050041', '2024-10-05', '2025-04-05', 'Mr jayantha', '0717748422', 'Paid', 3433.00, 5.00, 3261.35),
(44, 'SP202410050042', '2024-10-05', '2024-12-05', 'Yohan Perera', '0717748422', 'Partial', 7883.00, 2.00, 7725.34);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice_id`, `product_id`, `quantity`, `price`) VALUES
(2, 3, 3, 1, 3500.00),
(3, 4, 3, 1, 3500.00),
(4, 5, 3, 1, 3500.00),
(5, 6, 1, 1, 3433.00),
(6, 6, 3, 2, 3500.00),
(7, 7, 1, 1, 3433.00),
(8, 7, 3, 1, 3500.00),
(9, 8, 1, 1, 3433.00),
(10, 8, 3, 2, 3500.00),
(11, 9, 1, 1, 3433.00),
(12, 9, 3, 2, 3500.00),
(13, 10, 1, 1, 3433.00),
(14, 10, 3, 1, 3500.00),
(15, 11, 3, 1, 3500.00),
(16, 11, 1, 1, 3433.00),
(17, 12, 3, 1, 3500.00),
(18, 12, 1, 1, 3433.00),
(19, 13, 3, 1, 3500.00),
(20, 14, 3, 1, 3500.00),
(21, 14, 1, 1, 3433.00),
(22, 15, 3, 1, 3500.00),
(23, 15, 1, 1, 3433.00),
(24, 16, 3, 1, 3500.00),
(25, 16, 1, 1, 3433.00),
(26, 17, 3, 1, 3500.00),
(27, 17, 1, 1, 3433.00),
(28, 18, 3, 1, 3500.00),
(29, 19, 3, 1, 3500.00),
(30, 20, 3, 1, 3500.00),
(31, 21, 1, 1, 3433.00),
(32, 22, 1, 1, 3433.00),
(33, 22, 3, 1, 3500.00),
(34, 23, 1, 1, 3433.00),
(35, 23, 3, 1, 3500.00),
(36, 24, 4, 1, 950.00),
(37, 25, 4, 1, 950.00),
(38, 26, 3, 1, 3500.00),
(39, 26, 1, 1, 3433.00),
(40, 27, 3, 1, 3500.00),
(41, 27, 1, 1, 3433.00),
(42, 28, 3, 1, 3500.00),
(43, 28, 1, 1, 3433.00),
(44, 29, 3, 1, 3500.00),
(45, 29, 1, 1, 3433.00),
(46, 30, 3, 1, 3500.00),
(47, 30, 1, 1, 3433.00),
(48, 31, 4, 1, 950.00),
(49, 32, 4, 1, 950.00),
(50, 32, 3, 1, 3500.00),
(51, 32, 1, 1, 3433.00),
(52, 33, 3, 1, 3500.00),
(53, 33, 1, 1, 3433.00),
(54, 34, 4, 1, 950.00),
(55, 34, 3, 1, 3500.00),
(56, 34, 1, 1, 3433.00),
(57, 35, 4, 3, 950.00),
(58, 35, 1, 1, 3433.00),
(59, 36, 4, 3, 950.00),
(60, 36, 1, 1, 3433.00),
(61, 38, 1, 1, 3433.00),
(62, 39, 4, 1, 950.00),
(63, 40, 3, 2, 3500.00),
(64, 40, 4, 1, 950.00),
(65, 41, 4, 1, 950.00),
(66, 41, 1, 1, 3433.00),
(67, 42, 1, 1, 3433.00),
(68, 43, 1, 1, 3433.00),
(69, 44, 1, 1, 3433.00),
(70, 44, 3, 1, 3500.00),
(71, 44, 4, 1, 950.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_number` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_number`, `name`, `price`) VALUES
(1, 'P00003', 'heloo kitty', 3433.00),
(3, 'P0001', 'Spotify', 3500.00),
(4, 'P0002', 'Netflix 1 month', 950.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_number` (`product_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoice_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
